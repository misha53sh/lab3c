﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IntegralWinForms.Classes
{
    public class Integral
    {
        private Func<double, double> _F;
        private double a;
        private double b;
        private long n;

        public double A
        {
            get
            {
                return a;
            }
        }

        public double B
        {
            get
            {
                return b;
            }
        }

        public long N
        {
            get
            {
                return n;
            }
        }

        public void SetData(double a, double b, long N, Func<double, double> f)
        {
            this.a = a;
            this.b = b;
            this.n = N;
            _F = f;

        }
        public Integral(double a, double b, long N, Func<double, double> f)
        {
            SetData(a, b, N, f);



        }

        public double Rectangle(out double time)
        {
            Stopwatch sw1;
            sw1 = new Stopwatch();
            sw1.Start();
            time = 0;
            double res = CalcRectangle(a, b, n, _F);
            sw1.Stop();
            time = sw1.ElapsedMilliseconds;
            return res;

        }

        public double RectangleParallel(out double time)
        {
            Thread oneThread = new Thread(CalcRectangle(a, b, n, _F));
              oneThread.Start();
            Stopwatch sw1;
            sw1 = new Stopwatch();
            sw1.Start();
            
            time = 0;
            double res = CalcRectangle(a, b, n, _F);
            sw1.Stop();
            time = sw1.ElapsedMilliseconds;
            return res;
              oneThread.Join();
        }


        private double CalcRectangle(double a, double b, long N, Func<double, double> f)
        {
            double h = (b - a) / n;
            double S = 0;
            for (int i = 0; i < n; i++)
            {
                S += _F(a + i * h);
            }
            S *= h;
            return S;
        }

        private double CalcRectanglePar(double a, double b, long N, Func<double, double> f)
        {
            double h = (b - a) / n;
            double S = 0;
            for (int i = 0; i < n; i++)
            {
                S += _F(a + i * h);
            }
            S *= h;
            return S;
        }

    }
}
