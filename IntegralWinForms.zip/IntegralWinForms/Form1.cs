﻿using IntegralWinForms.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegralWinForms
{
    public partial class Form1 : Form
    {

        private double SumIntegral(double x)
        {
            return 11 * x - Math.Log(11 * x) - 2;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rtbLog_TextChanged(object sender, EventArgs e)
        {

        }

        private void btCalc_Click(object sender, EventArgs e)
        {
            double time;
            double a=Convert.ToDouble(tbA.Text);

            double b = Convert.ToDouble(tbB.Text);
            long N = Convert.ToInt64(nudN.Text);

            Integral int1 = new Integral(a, b, N, SumIntegral);
            double result=int1.Rectangle(out time);
            rtbLog.AppendText("Ответ:" + result.ToString()+Environment.NewLine);
            rtbLog.AppendText("Время:" + time.ToString() + Environment.NewLine);
        }
    }
}
